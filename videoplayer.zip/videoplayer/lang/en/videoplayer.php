<?php
$string['pluginname'] = 'Video Elearning Cloud';
$string['modulename'] = 'Video Elearning Cloud';
$string['modulenameplural'] = 'Videos Elearning Cloud';
$string['videoname'] = 'Título del video';
$string['videourl'] = 'Enlace de Google Drive';
$string['invalidurl'] = 'URL de Google Drive no válida. Asegúrate de usar el formato correcto.';
