<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'mod_videoplayer';
$plugin->version = 2025071500;
$plugin->requires = 2022041900; // Moodle 4.1
$plugin->maturity = MATURITY_STABLE;
$plugin->release = '1.0';
