<?php
// Archivo requerido por Moodle aunque esté vacío.
